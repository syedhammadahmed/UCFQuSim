//
// Created by hammad on 9/26/19.
//

#include "QuRegister.h"

QuRegister::QuRegister() {

}

QuRegister::QuRegister(int n) {

}

QuRegister::QuRegister(const QuRegister &) {

}

bool QuRegister::isValid() {
    return false;
}

void QuRegister::print() {

}

QuRegister::~QuRegister() {

}

//
// Created by hammad on 9/26/19.
//

#include <iostream>
#include <fstream>
#include "QuCircuit.h"

using namespace std;

QuCircuit::QuCircuit(int rows, int cols): rows(rows), cols(cols), quBitConfiguration(NULL), quBitMapping(NULL), grid(NULL) {
    quBitConfiguration = new int[rows];
    for(int i=0; i<rows; i++)
        quBitConfiguration[i] = i; // it may change due to swap initial mapping: [0] = 0, [1] = 1, ...
    quBitMapping = new int[rows];
    quBitNextLayer = new int[rows];
    grid = new QuGate**[rows];
    for(int i=0; i<rows; i++)
        grid[i] = new QuGate*[cols];
//    for (int i = 0; i < rows; i++)
//        for (int j = 0; j < cols; j++)
//            grid[i][j] = NULL;
}


QuCircuit::~QuCircuit() {
    for(int i=0; i<rows; i++)
        delete [] grid[i];
    delete [] grid;
}


void QuCircuit::add(QuGate* gate, int row, int depth) {
    grid[row][depth] = gate;
}

void QuCircuit::run() {
    std::cout << "Circuit execution start..." << std::endl;
    // todo: apply each gate depth-wise
    std::cout << "Circuit execution end..." << std::endl;
}

void QuCircuit::addMapping(int logicalQuBit, int physicalQuBit) {
    quBitMapping[logicalQuBit] = physicalQuBit;
}

std::ostream &operator<<(std::ostream &os, const QuCircuit &circuit) {
    int temp = 0;
    for (int i = 0; i < circuit.rows; i++) {
        os << "q" << i << " : ";
        for (int j = 0; j < circuit.cols; j++) {
            if (circuit.grid[i][j] != NULL) {
                for (int k = temp+1; k < j; k++) {
                    os << "-";
                }
                os << circuit.grid[i][j]->getSymbol();
                temp = j;
            }
        }
        os << std::endl;
    }
    return os;
}

QuCircuit::QuCircuit(string fileName) {
    ifstream ifs;
    string quGate = "";
    string qubitArgs = "";
    int gates[QuGate::MAX_OPERANDS] = {-1, -1, -1};
    int pos1 = 0;
    int pos2 = 0;
    int i = 0;

    ifs.open(fileName);
    while (!ifs.eof()){
        i = 0;
        pos1 = 0;
        pos2 = 0;
        ifs >> quGate;
        ifs >> qubitArgs;
        cout << ">>>> " << quGate << " --- " << qubitArgs << endl;
        if((quGate.find("[") != string::npos) || (qubitArgs.find("[") != string::npos)) {
            while (pos1 != string::npos) {
                pos1 = qubitArgs.find("[", pos1 + 1);
                pos2 = qubitArgs.find("]", pos1 + 1);
                if ((pos1 != string::npos) && (pos2 != string::npos)) {
                    cout << ">>>> " << stoi(qubitArgs.substr(pos1 + 1, pos2 - pos1 - 1)) << " <<<<" << endl;
                    gates[i++] = stoi(qubitArgs.substr(pos1 + 1, pos2 - pos1 - 1));
                }
            }
            for (int j = 0; j < QuGate::MAX_OPERANDS; j++) {
                cout << gates[j] << endl;
                gates[j] = -1;
            }
        }
    }
    ifs.close();

}


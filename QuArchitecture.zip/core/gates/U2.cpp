//
// Created by hammad on 10/8/19.
//

#include "U2.h"

void U2::apply(QuBit *bit, int i) {

}

//
// Created by hammad on 10/8/19.
//

#include "CZ.h"

void CZ::apply(QuBit *bit, int i) {

}

//
// Created by hammad on 10/8/19.
//

#include "Sdg.h"

void Sdg::apply(QuBit *bit, int i) {

}

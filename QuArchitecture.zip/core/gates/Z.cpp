//
// Created by hammad on 10/8/19.
//

#include "Z.h"

void Z::apply(QuBit *bit, int i) {

}

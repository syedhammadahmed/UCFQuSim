//
// Created by hammad on 10/8/19.
//

#include "U3.h"

void U3::apply(QuBit *bit, int i) {

}


//
// Created by hammad on 10/8/19.
//

#include "Y.h"

void Y::apply(QuBit *bit, int i) {

}

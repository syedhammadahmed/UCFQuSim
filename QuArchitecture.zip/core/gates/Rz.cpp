//
// Created by hammad on 10/8/19.
//

#include "Rz.h"

void Rz::apply(QuBit *bit, int i) {

}

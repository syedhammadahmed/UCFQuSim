//
// Created by hammad on 10/8/19.
//

#include "Tdg.h"

void Tdg::apply(QuBit *bit, int i) {

}

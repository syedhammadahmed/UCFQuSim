//
// Created by hammad on 10/8/19.
//

#include "CU1.h"

void CU1::apply(QuBit *bit, int i) {

}

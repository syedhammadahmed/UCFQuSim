//
// Created by hammad on 10/8/19.
//

#include "Toffoli.h"

void Toffoli::apply(QuBit *bit, int i) {

}

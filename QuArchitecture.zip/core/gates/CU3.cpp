//
// Created by hammad on 10/8/19.
//

#include "CU3.h"

void CU3::apply(QuBit *bit, int i) {

}

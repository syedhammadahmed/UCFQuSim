//
// Created by hammad on 10/8/19.
//

#include "Ry.h"

void Ry::apply(QuBit *bit, int i) {

}

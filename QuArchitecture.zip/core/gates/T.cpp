//
// Created by hammad on 10/8/19.
//

#include "T.h"

void T::apply(QuBit *bit, int i) {

}

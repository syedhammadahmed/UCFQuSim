//
// Created by hammad on 9/26/19.
//

#include "Measure.h"

void Measure::apply(QuBit *bit, int i) {

}

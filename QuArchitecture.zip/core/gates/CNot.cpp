//
// Created by hammad on 9/26/19.
//

#include "CNot.h"

CNot::CNot(int depth, int cardinality) : QuGate(depth, cardinality) {


}

void CNot::apply(QuBit *bit, int i) {

}

CNot::CNot() {

}

//
// Created by hammad on 9/26/19.
//

#include "Swap.h"

void Swap::apply(QuBit *bit, int i) {

}

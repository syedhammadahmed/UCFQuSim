//
// Created by hammad on 10/8/19.
//

#include "U1.h"

void U1::apply(QuBit *bit, int i) {

}
